"use client";

import React, { useState } from 'react';

interface TrimSliderProps {
  duration: number;
  onTrimChange: (start: number, end: number) => void;
}

export default function TrimSlider({ duration, onTrimChange }: TrimSliderProps) {
  const [start, setStart] = useState(0);
  const [end, setEnd] = useState(duration);

  const handleStartChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    if (val < end) {
      setStart(val);
      onTrimChange(val, end);
    }
  };

  const handleEndChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    if (val > start) {
      setEnd(val);
      onTrimChange(start, val);
    }
  };

  const formatTime = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = Math.floor(s % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="glass" style={{ padding: '1.5rem', marginTop: '1rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
        <span style={{ fontSize: '0.9rem', color: 'rgba(255,255,255,0.6)' }}>Trim Range:</span>
        <span className="gradient-text" style={{ fontWeight: '700' }}>{formatTime(start)} — {formatTime(end)}</span>
      </div>
      
      <div style={{ position: 'relative', height: '40px' }}>
        <input 
          type="range" 
          min="0" 
          max={duration} 
          value={start} 
          onChange={handleStartChange}
          style={{ width: '100%', position: 'absolute', top: 0, zIndex: 1 }}
        />
        <input 
          type="range" 
          min="0" 
          max={duration} 
          value={end} 
          onChange={handleEndChange}
          style={{ width: '100%', position: 'absolute', top: '15px', zIndex: 2 }}
        />
      </div>
    </div>
  );
}
