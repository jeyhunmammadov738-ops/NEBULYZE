"use client";

import React, { useState, useEffect } from 'react';
import TrimSlider from '../components/TrimSlider';

export default function Home() {
  const [url, setUrl] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const [trim, setTrim] = useState({ start: 0, end: 120 });
  const [showProgress, setShowProgress] = useState(false);
  const [progress, setProgress] = useState(0);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      console.log("File dropped:", files[0].name);
      handleProcess();
    }
  };

  const handleProcess = () => {
    setShowProgress(true);
    setProgress(0);
    // Mock progression for Demo
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 2;
      });
    }, 100);
  };

  return (
    <main style={{ minHeight: '100vh', padding: '2rem', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      {/* Header */}
      <header style={{ width: '100%', maxWidth: '1200px', display: 'flex', justifyContent: 'center', marginBottom: '4rem' }}>
        <h1 className="gradient-text animate-float" style={{ fontSize: '3.5rem', fontWeight: '800', letterSpacing: '-2px' }}>
          NEBULYZE
        </h1>
      </header>

      {/* Hero Section */}
      <section style={{ textAlign: 'center', marginBottom: '4rem', maxWidth: '800px' }}>
        <h2 style={{ fontSize: '2.5rem', marginBottom: '1rem', fontWeight: '700' }}>
          Sonic Clarity at <span className="gradient-text">Light Speed</span>
        </h2>
        <p style={{ fontSize: '1.2rem', color: 'rgba(255,255,255,0.6)', lineHeight: '1.6' }}>
          Convert MP4 to studio-grade MP3 with our gravity-defying engine. 
          Support for 320k production, visual trimming, and instant URL extraction.
        </p>
      </section>

      {/* Conversion Core */}
      <div className="glass" style={{ width: '100%', maxWidth: '900px', padding: '3rem', position: 'relative' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) auto minmax(0, 1fr)', alignItems: 'center', gap: '2rem', marginBottom: '3rem' }}>
          
          {/* File Upload */}
          <div 
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            style={{ 
              height: '240px', 
              border: `2px dashed ${isDragging ? 'var(--primary-cyan)' : 'var(--glass-border)'}`,
              borderRadius: '20px',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
              background: isDragging ? 'rgba(0, 242, 255, 0.05)' : 'transparent'
            }}
          >
            <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>📥</div>
            <p style={{ fontWeight: '600' }}>Drag & Drop MP4</p>
            <p style={{ fontSize: '0.85rem', color: 'rgba(255,255,255,0.4)', marginTop: '0.5rem' }}>Up to 100MB production limit</p>
          </div>

          <div style={{ color: 'rgba(255,255,255,0.2)', fontWeight: '800' }}>OR</div>

          {/* URL Input */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <input 
              type="text" 
              placeholder="Paste Video URL (YouTube, TikTok, Instagram...)" 
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="glass"
              style={{
                width: '100%',
                padding: '1.2rem',
                border: '1px solid var(--glass-border)',
                outline: 'none',
                color: 'white',
                fontSize: '1rem'
              }}
            />
            
            <TrimSlider duration={300} onTrimChange={(start, end) => setTrim({ start, end })} />

            <button className="btn-primary" onClick={handleProcess} style={{ width: '100%', padding: '1.2rem' }}>
              REACH NEBULA
            </button>
          </div>
        </div>

        {/* Progress Display */}
        {showProgress && (
          <div style={{ marginTop: '2rem', borderTop: '1px solid var(--glass-border)', paddingTop: '2rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
              <span>{progress < 100 ? 'Processing Engine...' : 'Ready for Reentry'}</span>
              <span className="gradient-text" style={{ fontWeight: '800' }}>{progress}%</span>
            </div>
            <div className="glass" style={{ height: '8px', width: '100%', overflow: 'hidden' }}>
              <div style={{ 
                width: `${progress}%`, 
                height: '100%', 
                background: 'linear-gradient(90deg, var(--primary-cyan), var(--primary-violet))',
                transition: 'width 0.2s ease'
              }}></div>
            </div>
            {progress === 100 && (
              <button className="btn-primary" style={{ marginTop: '1.5rem', width: '100%', background: 'var(--fg-light)', color: 'var(--bg-deep)' }}>
                📥 DOWNLOAD MP3
              </button>
            )}
          </div>
        )}
      </div>

      {/* Features Grid */}
      <footer style={{ marginTop: '5rem', width: '100%', maxWidth: '1200px', display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '2rem' }}>
        <FeatureCard icon="⚡" title="Warp Speed" desc="Proprietary Celery-Worker pipeline for near-instant rendering." />
        <FeatureCard icon="💎" title="Studio Grade" desc="Lossless 320kbps scaling and dynamic fidelity adjustment." />
        <FeatureCard icon="✂️" title="Visual Trim" desc="Precision audio cutting with frame-accurate validation layer." />
      </footer>
    </main>
  );
}

function FeatureCard({ icon, title, desc }: { icon: string, title: string, desc: string }) {
  return (
    <div className="glass" style={{ padding: '2rem', textAlign: 'center' }}>
      <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>{icon}</div>
      <h3 style={{ marginBottom: '0.5rem', fontWeight: '700' }}>{title}</h3>
      <p style={{ fontSize: '0.9rem', color: 'rgba(255,255,255,0.5)', lineHeight: '1.4' }}>{desc}</p>
    </div>
  );
}
