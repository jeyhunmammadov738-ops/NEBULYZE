from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import os
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(
    title="Nebulyze API",
    description="High-performance media conversion platform",
    version="1.0.0"
)

from .db.database import init_db

@app.on_event("startup")
async def on_startup():
    await init_db()

# CORS for Next.js frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # In production, restrict to frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def health_check():
    return {"status": "Nebulyze Engine Online", "version": "1.0.0"}

# Include routers
from .api.endpoints import router
app.include_router(router, prefix="/api/v1")
