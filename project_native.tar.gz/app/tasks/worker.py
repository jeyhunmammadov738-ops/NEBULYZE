from .celery_app import celery_app
from ..core.engine import convert_to_mp3, convert_to_voice
import os
import logging

logger = logging.getLogger(__name__)

@celery_app.task(bind=True)
def convert_media_task(self, input_path: str, output_path: str, bitrate: str = "192k", fmt: str = "mp3", trim=None):
    """
    Background task for media conversion.
    Updates progress state for frontend/bot to poll.
    """
    self.update_state(state="PROGRESS", meta={"status": "Initializing conversion engine..."})
    
    try:
        if fmt == "mp3":
            convert_to_mp3(input_path, output_path, bitrate, trim)
        else:
            convert_to_voice(input_path, output_path, trim)
            
        # Aggressive cleanup: remove input file after successful conversion
        if os.path.exists(input_path):
            os.remove(input_path)
            logger.info(f"Cleaned up input file: {input_path}")
            
        self.update_state(state="SUCCESS", meta={"status": "Conversion complete!", "output_path": output_path})
        return {"status": "SUCCESS", "output_path": output_path}
        
    except Exception as e:
        logger.error(f"Task failed: {e}")
        # Even if it fails, we might want to clean up the input if it's in temp_uploads
        if "temp_uploads" in input_path and os.path.exists(input_path):
            os.remove(input_path)
        self.update_state(state="FAILURE", meta={"status": str(e)})
        raise e
