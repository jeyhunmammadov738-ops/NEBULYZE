from fastapi import APIRouter, UploadFile, File, BackgroundTasks, HTTPException
from fastapi.responses import JSONResponse
import shutil
import os
import uuid
from typing import Optional
from fastapi import WebSocket, WebSocketDisconnect
from typing import List, Dict

class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}

    async def connect(self, client_id: str, websocket: WebSocket):
        await websocket.accept()
        self.active_connections[client_id] = websocket

    def disconnect(self, client_id: str):
        if client_id in self.active_connections:
            del self.active_connections[client_id]

    async def send_personal_message(self, message: str, client_id: str):
        if client_id in self.active_connections:
            await self.active_connections[client_id].send_text(message)

manager = ConnectionManager()

@router.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: str):
    await manager.connect(client_id, websocket)
    try:
        while True:
            # Keep connection alive
            data = await websocket.receive_text()
            # Handle client heartbeats or messages if needed
    except WebSocketDisconnect:
        manager.disconnect(client_id)
from ..tasks.worker import convert_media_task
from celery.result import AsyncResult

router = APIRouter()
TEMP_UPLOAD_DIR = "temp_uploads"
os.makedirs(TEMP_UPLOAD_DIR, exist_ok=True)

@router.post("/upload")
async def upload_file(
    file: UploadFile = File(...), 
    bitrate: str = "192k", 
    fmt: str = "mp3", 
    trim: Optional[str] = None
):
    """
    Endpoint for direct file uploads.
    Saves file to disk and enqueues conversion task.
    """
    file_id = str(uuid.uuid4())
    ext = file.filename.split('.')[-1]
    input_path = os.path.join(TEMP_UPLOAD_DIR, f"{file_id}.{ext}")
    
    with open(input_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
        
    output_ext = "mp3" if fmt == "mp3" else "ogg"
    output_path = os.path.join(TEMP_UPLOAD_DIR, f"{file_id}_final.{output_ext}")
    
    # Optional: Parse trim from string "MM:SS-MM:SS" if needed
    trim_params = None
    if trim:
        try:
            parts = trim.split('-')
            def p(t): p=t.split(':'); return int(p[0])*60 + int(p[1])
            trim_params = (p(parts[0]), p(parts[1]))
        except: pass

    task = convert_media_task.delay(input_path, output_path, bitrate, fmt, trim_params)
    
    return {
        "task_id": task.id,
        "file_id": file_id,
        "status": "QUEUED"
    }

@router.get("/status/{task_id}")
async def get_status(task_id: str):
    """
    Poll task status from Celery.
    Returns state and any metadata (e.g. progress percentage).
    """
    res = AsyncResult(task_id)
    return {
        "status": res.state,
        "info": res.info # contains the metadata updated via self.update_state
    }

@router.get("/download/{task_id}")
async def download_result(task_id: str):
    """
    Provide download link for finished files.
    """
    res = AsyncResult(task_id)
    if res.state == "SUCCESS":
        # logic to serve file... (e.g. FileResponse)
        pass
    else:
        raise HTTPException(status_code=400, detail="Task not finished or failed.")

import yt_dlp
from typing import Tuple

@router.post("/url")
async def extract_url(url: str, bitrate: str = "192k", fmt: str = "mp3"):
    """
    Endpoint for URL-based extraction (YouTube, TikTok, etc.)
    Downloads file temporarily and enqueues conversion.
    """
    file_id = str(uuid.uuid4())
    ydl_opts = {
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
        'outtmpl': os.path.join(TEMP_UPLOAD_DIR, f"{file_id}.%(ext)s"),
        'max_filesize': 100 * 1024 * 1024, # 100MB limit
        'quiet': True,
        'postprocessors': [{'key': 'FFmpegVideoConvertor', 'preferedformat': 'mp4'}],
    }
    
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            input_path = ydl.prepare_filename(info)
            # Ensure it's standardized to .mp4
            if not input_path.endswith('.mp4'):
                input_path = os.path.splitext(input_path)[0] + '.mp4'
            
            output_ext = "mp3" if fmt == "mp3" else "ogg"
            output_path = os.path.join(TEMP_UPLOAD_DIR, f"{file_id}_final.{output_ext}")
            
            task = convert_media_task.delay(input_path, output_path, bitrate, fmt)
            
            return {
                "task_id": task.id,
                "title": info.get('title'),
                "uploader": info.get('uploader'),
                "status": "QUEUED"
            }
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"URL Extraction Failed: {str(e)}")
